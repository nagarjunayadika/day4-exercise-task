function Button(props){
    return(
        <button>
            <span>{props.action}</span>
        </button>
    )
}
export default Button;